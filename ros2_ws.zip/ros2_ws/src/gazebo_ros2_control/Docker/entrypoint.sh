#!/bin/sh

. /opt/ros/foxy/setup.sh
. /home/ros2_ws/install/setup.sh
exec "$@"
