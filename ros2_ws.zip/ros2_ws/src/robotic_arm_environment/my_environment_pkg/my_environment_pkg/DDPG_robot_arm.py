"""
Author: David Valencia
Date: 11/ 04 /2022

Describer:

"""


def main():

    EPISODE = 2000
    batch_size = 128
    # -------------------------------


if __name__ == '__main__':
    main()
